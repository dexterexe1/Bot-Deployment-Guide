export { WelcomePage } from './page'
