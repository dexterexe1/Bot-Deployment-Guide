## 1. Architecture Design

```mermaid
flowchart LR
  U["Browser (React SPA)"] -->|HTTPS| B["Express API (Node)"]
  B --> M["MongoDB"]
  B --> D["Discord API (OAuth2 + REST)"]
  B --> X["Bot Bridge (Later: Python bot integration)"]
```

## 2. Technology Description

- Frontend: React (Vite) + TypeScript + Tailwind CSS + shadcn/ui + Framer Motion
- Backend: Express.js + TypeScript (ESM)
- Database: MongoDB (primary persistence + session store)
- Authentication: Discord OAuth2 (Authorization Code)
- Session: server-side session with Mongo-backed store, httpOnly cookie, secure in production
- Deployment: Render (separate services for API and Web, or monorepo with two deploy targets)

## 3. Route Definitions (Frontend)

| Route | Purpose |
|-------|---------|
| /login | Sign in via Discord OAuth2 |
| /auth/callback | OAuth callback handler page (mostly redirect/feedback) |
| /app | Protected app layout |
| /app/select | Guild selector landing (optional; can be embedded in /app) |
| /app/:guildId/overview | Guild overview homepage |

## 4. API Definitions (Backend)

All APIs are versioned under `/api/v1`. Responses are JSON and use a consistent envelope for errors.

### 4.1 Auth

| Method | Route | Purpose |
|--------|-------|---------|
| GET | /api/v1/auth/discord/login | Redirect to Discord OAuth authorize URL |
| GET | /api/v1/auth/discord/callback | Exchange code, establish session, redirect to web |
| POST | /api/v1/auth/logout | Destroy session |
| GET | /api/v1/auth/me | Get current session user (Discord profile cache) |

### 4.2 Meta

| Method | Route | Purpose |
|--------|-------|---------|
| GET | /api/v1/meta | Dashboard version + environment metadata |
| GET | /api/v1/health | Health check (DB connectivity) |

### 4.3 Guilds

| Method | Route | Purpose |
|--------|-------|---------|
| GET | /api/v1/guilds | List guilds from Discord `/users/@me/guilds` filtered to manageable guilds |
| GET | /api/v1/guilds/:guildId | Guild details available from Discord OAuth context (limited) |
| GET | /api/v1/guilds/:guildId/overview | Aggregated overview (Discord + DB cache + bot bridge later) |

### 4.4 Types (Conceptual)

```ts
export type ApiError = {
  code: string
  message: string
  requestId: string
}

export type ApiResponse<T> =
  | { ok: true; data: T }
  | { ok: false; error: ApiError }

export type SessionUser = {
  discordUserId: string
  username: string
  globalName?: string | null
  avatar?: string | null
}

export type GuildSummary = {
  id: string
  name: string
  icon?: string | null
  permissions: string
}

export type GuildOverview = {
  guild: {
    id: string
    name: string
    iconUrl?: string | null
    ownerId?: string | null
  }
  stats: {
    memberCount?: number | null
    channelCount?: number | null
    roleCount?: number | null
  }
  bot: {
    status?: "online" | "offline" | null
    latencyMs?: number | null
    joinedAt?: string | null
  }
  meta: {
    dashboardVersion: string
  }
  recentActivity: Array<unknown>
}
```

## 5. Server Architecture Diagram

```mermaid
flowchart TD
  R["Routes"] --> C["Controllers"]
  C --> S["Services"]
  S --> P["Providers"]
  P --> DA["Discord API Client"]
  P --> REPO["Repositories"]
  REPO --> DB["MongoDB"]
  P --> BR["Bot Bridge Client (Later)"]
```

## 6. Data Model

### 6.1 Data Model Definition

```mermaid
erDiagram
  USER ||--o{ USER_GUILD : "has"
  USER {
    string _id
    string discordUserId
    string username
    string avatar
    date createdAt
    date updatedAt
  }
  USER_GUILD {
    string _id
    string discordUserId
    string guildId
    string roleHint
    date lastSeenAt
  }
  GUILD_SETTINGS {
    string _id
    string guildId
    object settings
    date createdAt
    date updatedAt
  }
  GUILD_CACHE {
    string _id
    string guildId
    object snapshot
    date fetchedAt
  }
```

### 6.2 Persistence Notes (MongoDB)

- Sessions: stored in MongoDB using a session store (connect-mongo) to support multi-instance deployments on Render
- User identity: cached from Discord on login and refreshed as needed
- Guild cache: stores only real snapshots fetched from Discord/bot bridge; no seeded/mock records
- Guild settings: reserved for later phases; schema remains flexible but validated at API boundaries

## 7. Security Model (Phase Foundation)

- OAuth2:
  - Use Authorization Code flow
  - Validate `state` and restrict redirect URIs
  - Store OAuth tokens only server-side (never in browser storage)
- Sessions:
  - httpOnly cookie
  - `secure` enabled in production behind HTTPS
  - `sameSite=lax` by default
  - Rotate session on login
- API:
  - Centralized error handler and request ID
  - Rate limiting and hardening headers (foundation-level middleware)

## 8. Render Deployment Shape

- Web service: Vite build served as static site (or via lightweight Node static server if preferred)
- API service: Node/Express server
- MongoDB: external managed MongoDB (Atlas or Render)
- Configuration: `.env` per service, using `.env.example` as the canonical keys list
