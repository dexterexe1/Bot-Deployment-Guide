
# Project Context: United Bunnies Dashboard

## 1. Project Overview

### Purpose of the App
The United Bunnies Dashboard is a production-ready web interface for managing and viewing Discord server data for the existing United Bunnies Discord bot. It provides authenticated, server-scoped access for Discord guild owners/admins, plus a developer portal with global controls.

### Tech Stack
- **Frontend Framework**: React + TypeScript + Vite + @tanstack/react-start
- **Router**: @tanstack/react-router (file-based routing, auto-generated route tree at `src/routeTree.gen.ts`)
- **Styling System**: Tailwind CSS v4 + shadcn/ui + Framer Motion for animations
- **Dashboard Backend**: Express.js + TypeScript (in the `dashboard/api` directory, DO NOT TOUCH legacy `dashboard/` frontend)
- **Database**: MongoDB (primary persistence + session store)
- **Discord Bot**: Python 3 + discord.py + SQLite + motor (MongoDB async driver)
- **Authentication**: Discord OAuth2 (Authorization Code flow)


## 2. Architecture

### Important Folders
```
├── src/                          # Active application directory (NEW DASHBOARD FRONTEND, DO NOT touch dashboard/ frontend)
│   ├── components/               # Reusable UI components
│   │   ├── ui/                   # shadcn/ui components
│   │   ├── BunnyMascot.tsx       # Brand mascot component
│   │   └── CinematicBackground.tsx # Animated background
│   ├── features/                 # Feature modules (organized by domain)
│   │   ├── analytics/
│   │   ├── application/
│   │   ├── bot-management/
│   │   ├── layout/               # AppSidebar.tsx, etc.
│   │   ├── logging/
│   │   ├── reaction-roles/
│   │   ├── templates/
│   │   ├── tickets/
│   │   ├── welcome/
│   │   ├── developer-portal/     # NEW: Developer portal features
│   │   ├── premium/              # NEW: Premium features
│   │   ├── customization/        # NEW: Background/mouse customization
│   │   └── settings/
│   ├── hooks/                    # Custom hooks (useAuth.ts, useData.ts)
│   ├── layouts/                  # Shared layouts
│   ├── lib/                      # Utilities and API client
│   ├── routes/                   # File-based routes for @tanstack/react-router
│   │   ├── _app.tsx              # Protected app shell layout
│   │   └── _app/                 # Protected dashboard pages
│   │       ├── dashboard.tsx
│   │       ├── developer-portal.tsx
│   │       ├── premium.tsx
│   │       ├── customization.tsx
│   │       └── settings.tsx
│   ├── types/                    # Type definitions
│   ├── Shell.tsx                 # Main app shell component
│   └── index.css                 # Theme tokens (DO NOT EDIT WITHOUT APPROVAL)
├── dashboard/                    # Legacy/separate dashboard project (DO NOT TOUCH frontend, ONLY EXTEND api/)
│   ├── api/                      # Dashboard backend API (CAN BE EXTENDED)
│   │   ├── config/
│   │   ├── middleware/
│   │   ├── models/
│   │   ├── routes/
│   │   ├── utils/
│   │   ├── app.ts                # Express app
│   │   └── server.ts
│   └── shared/                   # Shared types
├── bot.py                        # Discord bot main file
├── mongo_bridge.py               # Bot ↔ MongoDB sync layer (critical for dashboard changes to take effect)
├── public/                       # Static assets
└── .trae/                        # PRD and technical docs
```

### Active Application Directory
- **Frontend**: All new development should happen in the **root `src/`** directory using @tanstack/react-start (this is the new frontend, replacing legacy `dashboard/src`).
- **Backend**: If you need to add API routes, only extend `dashboard/api` (do NOT touch `dashboard/src`).

### Folders That Should Not Be Touched
- **`dashboard/src`**: Legacy frontend project (maintained separately)
- **`src/routeTree.gen.ts`**: Auto-generated file, do not edit
- **`.git/`**: Git metadata directory



## 3. Core Components

### BunnyMascot.tsx
Brand mascot component with animated SVG bunny.

**Props**:
```ts
interface BunnyMascotProps {
  size?: 'sm' | 'md' | 'lg' | 'xl'  // Default: 'md'
  animated?: boolean                // Default: true
  glow?: boolean                    // Default: false
  className?: string
}
```

**Usage**:
```tsx
import { BunnyMascot } from '@/components/BunnyMascot'

<BunnyMascot size="lg" animated glow />
```

**Dependencies**:
- `framer-motion` for animations

### CinematicBackground.tsx
Animated background with aurora gradient, floating particles, and constellation-style bunny silhouettes. Can be customized via user settings.

**Props**:
```ts
interface CinematicBackgroundProps {
  config?: BackgroundConfig
}
```

**Usage**:
```tsx
import { CinematicBackground } from '@/components/CinematicBackground'

<CinematicBackground />
```

**Dependencies**:
- `framer-motion`
- `react` (useRef, useState, useEffect)

### Shell.tsx
Responsive app shell with sidebar and mobile drawer.

**Props**:
```ts
interface ShellProps {
  sidebar: ReactNode               // Sidebar content
  appName?: string                 // App name for mobile header
  backgroundConfig?: Partial<BackgroundConfig> // Live shell customization
  children: ReactNode              // Main content
}
```

**Usage**:
```tsx
import { Shell } from '@/Shell'

<Shell appName="United Bunnies" sidebar={<AppSidebar />}>
  <Outlet />
</Shell>
```

### AppSidebar.tsx
Collapsible sidebar with navigation links and mouse-following bunnies.

**Props**:
```ts
interface AppSidebarProps {
  config?: Partial<MouseFollowerConfig>
}
```

**Features**:
- Collapsible state saved to localStorage
- Navigation items: Overview (`/dashboard`), Developer Portal, Premium, Customization, Settings
- User profile section
- Large semi-transparent bunny that follows mouse horizontally
- Smaller semi-transparent bunny that follows mouse exactly
- Live mouse follower customization support from localStorage-backed settings

**Dependencies**:
- `lucide-react` for icons
- `@/components/ui/tooltip`, `@/components/ui/button`, `@/components/ui/avatar`
- `@/components/BunnyMascot`
- `@tanstack/react-router` for Link
- `framer-motion` (useMotionValue, useSpring) for mouse-following

### Authentication Components
- `src/routes/login.tsx`: Login page with Discord OAuth button (no visible bunnies, only silhouettes in background)
- `src/routes/auth.callback.tsx`: OAuth callback handler
- `src/hooks/useAuth.ts`: Auth state hook using @blinkdotnew/sdk

### Theme System
All theme tokens are defined in **`src/index.css`** and should only be edited there. Tokens use `oklch()` color format for consistency.

---

## 4. Routing

### Route Generation System
Uses **@tanstack/react-router** with file-based routing from `src/routes/`. The route tree is automatically generated and saved to `src/routeTree.gen.ts` (DO NOT EDIT THIS FILE).

### Existing Routes
| Route | File | Purpose |
|-------|------|---------|
| `/` | `src/routes/index.tsx` | Public full-bleed landing page |
| `/login` | `src/routes/login.tsx` | Discord OAuth login (no visible bunnies) |
| `/auth/callback` | `src/routes/auth.callback.tsx` | OAuth callback |
| `/_app` | `src/routes/_app.tsx` | Protected app layout (requires auth) |
| `/dashboard` | `src/routes/_app/dashboard.tsx` | Protected overview page inside the app shell |
| `/developer-portal` | `src/routes/_app/developer-portal.tsx` | Developer control center |
| `/premium` | `src/routes/_app/premium.tsx` | Premium command planning and UX |
| `/customization` | `src/routes/_app/customization.tsx` | Live background and mouse follower controls |
| `/settings` | `src/routes/_app/settings.tsx` | Workspace and AI handoff summary |

### Planned Routes
- Guild-scoped routes under `/_app/guilds/:guildId/...`

---

## 5. Existing Systems

### Dashboard API (dashboard/api)
Express.js backend with the following existing routes:
- `/api/bot`: Bot status updates (from bot.py)
- `/api/v1/auth`: Discord OAuth2
- `/api/v1/meta`: Meta info
- `/api/v1/guilds/:guildId/*`: Guild-specific settings (welcome, tickets, reaction roles, logging, analytics, bot config)
- `/api/v1/templates`: Server templates

**Data Models (dashboard/api/models)**:
- BotStatus, BotConfig, GuildResourceSnapshot
- WelcomeConfig, TicketPanel, ReactionRolePanel
- LoggingConfig, ApplicationForm, ApplicationSubmission, ApplicationLog
- AnalyticsSnapshot, ServerTemplate, User
- Plus: commandCategories, guildCommandOverrides, customCommands, autoResponses, guildLeaderboards, moderationSettings, levelingSettings

### Mongo Bridge (mongo_bridge.py)
Critical sync layer between the Discord bot and MongoDB:
- Pulls settings from MongoDB every 20 seconds
- Caches settings in memory for fast access
- Supports: command categories/overrides, custom commands, auto responses, moderation settings, reaction panels, leveling settings, welcome settings, application forms, leaderboards
- Provides API for bot.py to read settings
- Provides API for bot.py to push leaderboard updates and mark panels as posted

### Discord Bot (bot.py)
Full-featured Discord bot with:
- Automod (anti-spam, word filter, link filter, caps lock, mass ping, new accounts, invites, emoji spam, duplicate messages)
- Leveling system
- Ticket system
- Reaction roles
- Welcome/leave messages
- Vouch system
- Music system
- Marriage system
- Custom commands (legacy SQLite + new MongoDB via mongo_bridge)
- Keep-alive server
- Bot status updates to dashboard

### Settings System
Will be implemented at `/customization` and `/settings` routes.

### Customization Systems
- **Background Customization**: Colors, particle density, bunny silhouette density/opacity, etc.
- **Mouse Customization**: Toggle mouse-following bunnies, adjust size/opacity, etc.
- Theme tokens in `src/index.css` (light/dark mode)
- Sidebar collapsible state (saved to localStorage)

### Theme Configuration
Defined entirely in `src/index.css` using CSS variables mapped to Tailwind utilities via `@theme inline`.

### Animation Configuration
Uses `framer-motion` for transitions and `tw-animate-css` for utility animations.

### State Management
- @tanstack/react-query for data fetching
- Built-in @tanstack/react-router state management

### API Structure
API client in `src/lib/api.ts`:
```ts
const API_BASE = '/api/v1'

async function apiRequest<T = unknown>(
  path: string,
  init?: RequestInit,
): Promise<ApiResult<T>>
```

---

## 6. New Requirements & Features

### 6.1 Developer Portal
**Location**: `/developer-portal`
**Access**: Restricted to bot developers/admins
**Implemented UI**:
- Dashboard page for global command control planning
- Server enforcement recommendations (ban, review, force leave)
- Developer customization access notes for backgrounds and mouse presets
- Backend integration notes for future enforcement

**Backend/Bot Work Still Needed**:
- **Global Command Control**: Enable/disable commands globally across all servers
- **Server Management**:
  - View all servers the bot is in
  - Ban/unban servers from using the bot
  - Remove bot from servers
- **Bot Status**: View real-time bot status, latency, guild count, member count
- **Analytics**: Global bot analytics

### 6.2 Premium Features
**Location**: `/premium`
**Implemented UI**:
- Premium section route and dashboard page
- Non-prefix command planning area
- Dyno-style custom command design notes and execution examples

**Backend/Bot Work Still Needed**:
- **Non-Prefix Commands**: Allow certain users/roles to use commands without the `?` prefix
- **Dyno-Style Custom Commands**: Advanced custom commands with variables, delays, multiple responses, permissions, etc.
- Premium badges/indicators

### 6.3 Customization
**Location**: `/customization`
**Implemented UI**:
- Live localStorage-backed customization page
- Background controls for aurora colors, particles, and silhouette bunny tuning
- Mouse follower controls for enabling, sizing, and opacity
- Shell wiring so `CinematicBackground.tsx` and `AppSidebar.tsx` react live

**Potential Future Expansion**:
- **Background Customization**:
  - Change aurora gradient colors
  - Adjust particle density/size/opacity
  - Toggle/change bunny silhouette settings (density, opacity, size, color)
- **Mouse Customization**:
  - Toggle mouse-following bunnies on/off
  - Adjust size/opacity of following bunnies
  - Change which bunnies follow (large, small, both)

---

## 7. Current Project Status

### Completed Changes
- Basic app shell with Shell.tsx
- BunnyMascot and CinematicBackground components
- AppSidebar with navigation links and mouse-following bunnies
- Basic routing setup with @tanstack/react-router
- Theme system with light/dark mode
- Login page without visible bunnies, only background silhouettes
- Protected dashboard routes for `/dashboard`, `/developer-portal`, `/premium`, `/customization`, and `/settings`
- LocalStorage-backed customization flow wired into the shell background and sidebar follower bunnies
- Developer portal and premium planning pages added to the new dashboard

### Approved Changes
All requirements listed above are approved.

### Pending Ideas/Tasks
- Add guild selector and guild-scoped routes
- Extend dashboard/api with new routes for:
  - Developer portal (global commands, server management)
  - Premium features
  - User customization settings
- Extend mongo_bridge.py and bot.py for:
  - Non-prefix commands
  - Advanced custom commands (Dyno-style)
  - Server banning
  - Global command overrides

### Known Missing Features
- Most feature modules are skeleton only
- Backend API integration for the new protected pages
- Guild-scoped dashboard

---

## 8. Development Rules

### Strict Rules (Must Follow)
1. **DO NOT touch the `dashboard/src` directory** - it's a separate legacy frontend project
2. **Use the root `src/` directory only** for all new frontend development
3. **You may extend `dashboard/api`** for new backend routes/models
4. **Do not create duplicate systems** - extend existing components
5. **Do not install dependencies without explicit approval**
6. **Show a diff before large changes**
7. **Read-only audit phase first** before making any changes

### Other Guidelines
- Use `BunnyMascot` for all UI states (loading, empty, error) instead of generic placeholders
- Maintain compatibility with existing props
- Follow the theme system defined in `src/index.css`
- Always update `mongo_bridge.py` when adding new MongoDB collections/models so the bot can use them

---

## 9. Full User Flow Walkthrough
### 9.1 Normal Server Owner/Mod User Flow
1. **Open App → Login Screen (`/login`):** User arrives at login page, sees cinematic background, clicks "Sign in with Discord" [login.tsx#L22-L28](file:///c:/Users/muphi/Downloads/my-discord-bot-main%20(2)/my-discord-bot-main/src/routes/login.tsx#L22-L28)
2. **Discord OAuth → Dashboard Shell (`/_app`):** Redirected to Discord OAuth, comes back authenticated, enters protected shell
3. **Dashboard Overview (`/_app/dashboard`):** Sees quick stats, focus areas, and quick server action links to bot modules and custom commands
4. **Guild Selection:** Uses dropdown in header to choose a server they manage; selection is remembered locally [_app.tsx#L72-L85](file:///c:/Users/muphi/Downloads/my-discord-bot-main%20(2)/my-discord-bot-main/src/routes/_app.tsx#L72-L85)
5. **Guild-Specific Navigation:** Second sidebar appears with server-focused links (Overview, Bot Modules, Custom Commands) [_app.tsx#L167-L190](file:///c:/Users/muphi/Downloads/my-discord-bot-main%20(2)/my-discord-bot-main/src/routes/_app.tsx#L167-L190)
6. **Bot Modules Page (`/_app/guilds/:guildId/bot`):** Toggles moderation/tickets/logging etc., clicks save (currently demo, simulates save) [bot.tsx#L72-L75](file:///c:/Users/muphi/Downloads/my-discord-bot-main%20(2)/my-discord-bot-main/src/routes/_app/guilds/$guildId/bot.tsx#L72-L75)
7. **Custom Commands Page (`/_app/guilds/:guildId/custom-commands`):** Creates Dyno-style custom commands with variables, permissions, cooldowns; edits/deletes existing ones [custom-commands.tsx#L144-L200](file:///c:/Users/muphi/Downloads/my-discord-bot-main%20(2)/my-discord-bot-main/src/routes/_app/guilds/$guildId/custom-commands.tsx#L144-L200)
8. **Premium (`/_app/premium`):** Views premium feature plans, non-prefix command setup
9. **Customization (`/_app/customization`):** Adjusts background colors, particle counts, bunny followers in sidebar with live preview
10. **Settings (`/_app/settings`):** Views/edits basic profile info (demo currently)

### 9.2 Developer (Bot Owner) User Flow
1. **Same Login/Dashboard as Normal User**
2. **Developer Portal (`/_app/developer-portal`):** Navigates via main sidebar [AppSidebar.tsx#L44-L58](file:///c:/Users/muphi/Downloads/my-discord-bot-main%20(2)/my-discord-bot-main/src/features/layout/AppSidebar.tsx#L44-L58)
3. **Global Command Controls:** Disables entire modules/commands across all servers (e.g., music commands globally off) [developer-portal.tsx#L54-L105](file:///c:/Users/muphi/Downloads/my-discord-bot-main%20(2)/my-discord-bot-main/src/routes/_app/developer-portal.tsx#L54-L105)
4. **Server Enforcement:** Bans/unbans servers, forces bot leave, flags high-risk guilds [developer-portal.tsx#L107-L123](file:///c:/Users/muphi/Downloads/my-discord-bot-main%20(2)/my-discord-bot-main/src/routes/_app/developer-portal.tsx#L107-L123)
5. **Global Customization Presets:** Creates/edits shared dashboard themes/background/mouse follower packs that normal users can select [developer-portal.tsx#L125-L143](file:///c:/Users/muphi/Downloads/my-discord-bot-main%20(2)/my-discord-bot-main/src/routes/_app/developer-portal.tsx#L125-L143)
6. **Bot Health:** Views latency, shard status, quick incident actions (demo currently) [developer-portal.tsx#L145-L165](file:///c:/Users/muphi/Downloads/my-discord-bot-main%20(2)/my-discord-bot-main/src/routes/_app/developer-portal.tsx#L145-L165)

## 10. New Guild-Scoped Routes (Added)
| Route | File | Purpose |
|-------|------|---------|
| `/_app/guilds/:guildId/bot` | `src/routes/_app/guilds/$guildId/bot.tsx` | Server-level bot module toggles |
| `/_app/guilds/:guildId/custom-commands` | `src/routes/_app/guilds/$guildId/custom-commands.tsx` | Dyno-style custom command editor |

# PROJECT_CONTEXT.md

## Project Purpose
A comprehensive Discord bot paired with a web dashboard for server management. The system allows server administrators to configure moderation, custom commands, auto-responders, leveling, reaction roles, and application forms via a web UI, which then syncs to the live Discord bot via a shared MongoDB database.

## Folder Structure
```text
├── bot.py                  # Main Discord bot entry point (Python)
├── mongo_bridge.py         # Syncs bot with dashboard MongoDB (polling)
├── requirements.txt        # Python dependencies
├── package.json            # Root JS/TS config (likely legacy/monorepo overlap)
├── vite.config.ts          # Root Vite config
├── dashboard/              # Main Web Application (Monorepo-style)
│   ├── api/                # Express + TypeScript backend
│   │   ├── config/         # Server configuration
│   │   ├── middleware/     # Auth, validation, error handling
│   │   ├── models/         # Mongoose/MongoDB schemas
│   │   ├── routes/         # API endpoints (v1/, bot.ts)
│   │   ├── providers/      # Dependency injection / DB providers
│   │   └── utils/          # Helper functions
│   ├── src/                # React + TypeScript frontend
│   │   ├── components/     # UI components (shadcn/ui)
│   │   ├── features/       # Feature-specific logic
│   │   ├── routes/         # TanStack Router definitions
│   │   └── lib/            # Utilities and API clients
│   ├── shared/             # Shared TypeScript types between API and UI
│   ├── render.yaml         # Render.com deployment config
│   └── package.json        # Dashboard-specific dependencies
├── scripts/                # Build/utility scripts (CSS var checks, etc.)
└── public/                 # Static assets

Backend Architecture
Discord Bot: Python 3.x using discord.py (hybrid slash/prefix commands), aiohttp, and motor (async MongoDB).
Dashboard API: Node.js with Express and TypeScript. Serves RESTful endpoints and likely handles Discord OAuth2.
Sync Mechanism: mongo_bridge.py polls MongoDB every 20 seconds to cache guild settings (commands, auto-responders, moderation, welcome messages, reaction panels, application forms). The bot also pushes leaderboard snapshots back to MongoDB.
Frontend Architecture
Framework: React 18+ with TypeScript.
Build Tool: Vite.
Styling: Tailwind CSS (v4) with custom CSS variable validation scripts.
UI Library: shadcn/ui (built on Radix UI primitives).
Routing & Data: TanStack Router (@tanstack/react-router) and TanStack Query (@tanstack/react-query).
Animations: Framer Motion.
Discord Bot Features
Moderation: /mod warn, mute, kick, ban, unban, clear (purge), and warning tracking (auto-timeout at 3 warnings).
Configuration: Interactive /mod setup dropdown dashboard, channel mapping (welcome, logs, level-up), no-prefix role/user grants.
Fun/Utility: gif, hug, kiss, pat, slap, roll, coinflip, choose, 8ball, avatar, userinfo, serverinfo, meme.
Dashboard-Synced: Custom commands, auto-responders, reaction role panels, application forms, and leveling/XP systems with role rewards.
API Routes (Inferred from Structure)
GET/POST /api/v1/auth/*: Discord OAuth2 login/callback.
GET /api/v1/guilds: Fetch user-managed guilds.
GET/PUT /api/v1/guilds/:id/settings: Moderation, welcome, and logging configs.
GET/POST/DELETE /api/v1/guilds/:id/commands: Custom commands and auto-responders.
GET/POST /api/v1/guilds/:id/panels: Reaction roles and ticket/application panels.
GET /api/v1/bot/status: Bot health and metrics.
Database Models (MongoDB)
Core: User, BotConfig, BotStatus.
Guild Settings: LoggingConfig, WelcomeConfig, ServerTemplate.
Features: ReactionRolePanel, TicketPanel, ApplicationForm, ApplicationSubmission, ApplicationLog.
Analytics: AnalyticsSnapshot, GuildResourceSnapshot.
Bot Cache Collections: commandCategories, guildCommandOverrides, customCommands, autoResponses, moderationSettings, levelingSettings, guildLeaderboards.
Authentication Flow
User clicks "Login with Discord" on the dashboard.
Redirects to Discord OAuth2 authorization screen.
Callback exchanges code for an access token and fetches user/guild data.
Backend generates a session cookie or JWT.
Frontend RequireAuth.tsx guard checks validity.
API middleware verifies the token and checks for MANAGE_GUILD permissions before allowing access to guild-specific settings.
Deployment Setup
Platform: Render.com (indicated by render.yaml).
Strategy: Likely a multi-service setup:
Web Service: Runs the Express API and serves the built Vite static files.
Worker/Background Service: Runs the Python bot.py script continuously.
Build Process: npm run build compiles the TS API and bundles the Vite frontend.
Environment Variables Needed
env
123456789101112
Current Problems / Unfinished Parts
Monorepo Overlap: Root directory contains both Python bot files and frontend configs (package.json, vite.config.ts), suggesting a messy or incomplete migration. The dashboard/ folder has its own complete setup.
Monolithic Bot File: bot.py is ~4,300 lines. It lacks cog-based modularization, making it hard to maintain.
Polling Delay: mongo_bridge.py uses a 20-second polling interval. This introduces latency between dashboard changes and bot execution, and is less efficient than event-driven updates.
Silent Failures: If MONGO_URI is misconfigured in production, the bot falls back silently to "disabled" mode, which could hide critical deployment errors.
Recommended Next Changes
Refactor Bot into Cogs: Split bot.py into discord.ext.commands.Cog modules (e.g., cogs/moderation.py, cogs/fun.py, cogs/sync.py).
Enforce Monorepo Boundaries: Move all Python bot files into a dedicated /bot directory at the root, keeping /dashboard strictly for the web app.
Implement Real-Time Sync: Replace polling in mongo_bridge.py with MongoDB Change Streams or Redis Pub/Sub for instant dashboard-to-bot updates.
Add Env Validation: Use pydantic-settings (Python) and zod (Node.js) at startup to crash early with clear errors if required environment variables are missing.
Improve Error Logging: Replace print() statements in mongo_bridge.py with a proper logging framework (e.g., logging module) to track sync failures in production.

