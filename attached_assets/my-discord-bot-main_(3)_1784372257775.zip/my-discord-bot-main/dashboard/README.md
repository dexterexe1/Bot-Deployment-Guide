# United Bunnies Dashboard (Foundation)

Production-ready dashboard foundation for the existing United Bunnies Python Discord bot.

This is a separate project under `./dashboard/` and integrates with the bot via:

- Discord OAuth2 (user authentication + guild list)
- MongoDB (shared database with the bot for settings + bot snapshots)
- Backend APIs (Express) used by the frontend and by the bot (bot status ingestion)

## Project Structure

- `src/`: React + TypeScript frontend (Vite + Tailwind + shadcn-style components + Framer Motion)
- `api/`: Express + TypeScript backend
- `shared/`: shared TypeScript types used by both frontend and backend

## Local Development

### 1) Configure env

Copy `./dashboard/.env.example` to `./dashboard/.env` and fill in:

- `MONGO_URI`, `MONGO_DB` (must match the bot’s `MONGO_URI/MONGO_DB`)
- `SESSION_SECRET`
- Discord OAuth app credentials (`DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`, `DISCORD_REDIRECT_URI`)
- `BOT_API_SECRET` (must match the bot’s `BOT_API_SECRET`)

Recommended local callback:

- `DISCORD_REDIRECT_URI=http://localhost:3001/api/v1/auth/discord/callback`

### 2) Install deps

```bash
cd dashboard
npm install
```

### 3) Run dev servers

```bash
cd dashboard
npm run dev
```

- Frontend: `http://localhost:5173`
- API: `http://localhost:3001`

## Backend Endpoints (Foundation)

- `GET /api/v1/auth/discord/login`: redirects to Discord OAuth2
- `GET /api/v1/auth/discord/callback`: exchanges code and establishes a secure session
- `GET /api/v1/auth/me`: session user (protected)
- `POST /api/v1/auth/logout`: destroy session
- `GET /api/v1/guilds`: manageable guilds (protected)
- `GET /api/v1/guilds/:guildId/overview`: overview payload (protected)
- `GET /api/v1/meta`: dashboard version
- `POST /api/bot/status`: bot → dashboard heartbeat ingestion (requires `x-bot-secret`)
- `GET /api/bot/status`: returns latest bot status snapshot

## Bot Integration Notes

The bot already publishes its status (online/ping/guild list + member counts) to:

- `POST /api/bot/status` with `x-bot-secret: BOT_API_SECRET`

The API stores this snapshot in MongoDB and uses it to populate the dashboard overview (real bot online/offline + latency + per-guild member count when available).

## Build

```bash
cd dashboard
npm run build
```

- `npm run build:web` outputs to `dashboard/dist`
- `npm run build:api` outputs to `dashboard/api/dist`

## Render Deployment

`./dashboard/render.yaml` provides a Render blueprint with:

- Node service for the API
- Static site for the web SPA (with SPA rewrite)

Ensure these env vars are set in the API service:

- `WEB_ORIGIN` (your web URL)
- `DASHBOARD_APP_URL` (your web URL)
- `DISCORD_REDIRECT_URI` (your API callback URL)
- `MONGO_URI`, `SESSION_SECRET`, `DISCORD_CLIENT_SECRET`, `BOT_API_SECRET`
