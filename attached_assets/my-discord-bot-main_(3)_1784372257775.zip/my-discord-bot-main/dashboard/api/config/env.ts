import dotenv from "dotenv"
import { z } from "zod"

dotenv.config()

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().int().positive().default(3001),

  WEB_ORIGIN: z.string().url().default("http://localhost:5173"),

  MONGO_URI: z.string().min(1),
  MONGO_DB: z.string().min(1).default("bunnydb"),

  SESSION_SECRET: z.string().min(32),
  SESSION_COOKIE_NAME: z.string().min(1).default("ubdash.sid"),
  SESSION_TTL_MS: z.coerce.number().int().positive().default(1000 * 60 * 60 * 24 * 7),

  DISCORD_CLIENT_ID: z.string().min(1),
  DISCORD_CLIENT_SECRET: z.string().min(1),
  DISCORD_REDIRECT_URI: z.string().url(),
  DISCORD_SCOPES: z.string().min(1).default("identify guilds"),

  DASHBOARD_APP_URL: z.string().url().default("http://localhost:5173"),
  DASHBOARD_VERSION: z.string().min(1).default("0.1.0"),

  BOT_API_SECRET: z.string().min(1).optional(),
})

export const env = envSchema.parse(process.env)
