import mongoose from "mongoose"
import { env } from "./env.js"

let connected = false

export async function connectMongo() {
  if (connected) return
  await mongoose.connect(env.MONGO_URI, { dbName: env.MONGO_DB })
  connected = true
}

