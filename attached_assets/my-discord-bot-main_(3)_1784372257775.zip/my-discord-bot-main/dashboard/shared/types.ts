export type ApiErrorPayload = {
  code: string
  message: string
  requestId: string
}

export type ApiResponse<T> =
  | { ok: true; data: T }
  | { ok: false; error: ApiErrorPayload }

export type SessionUser = {
  discordUserId: string
  username: string
  globalName?: string | null
  avatar?: string | null
}

export type GuildSummary = {
  id: string
  name: string
  icon?: string | null
  permissions: string
}

export type GuildOverview = {
  guild: {
    id: string
    name: string
    iconUrl?: string | null
    ownerId?: string | null
  }
  stats: {
    memberCount?: number | null
    channelCount?: number | null
    roleCount?: number | null
  }
  bot: {
    status?: "online" | "offline" | null
    latencyMs?: number | null
    joinedAt?: string | null
  }
  meta: {
    dashboardVersion: string
  }
  recentActivity: Array<unknown>
}

export type MetaInfo = {
  version: string
}

export type GuildChannelResource = {
  id: string
  name: string
  type: "text" | "voice" | "forum" | "announcement" | "stage" | "unknown"
  parentId?: string | null
  parentName?: string | null
  position: number
}

export type GuildCategoryResource = {
  id: string
  name: string
  position: number
}

export type GuildRoleResource = {
  id: string
  name: string
  color?: number | null
  managed: boolean
  position: number
}

export type GuildResourceSnapshot = {
  guildId: string
  fetchedAt: string | null
  channels: GuildChannelResource[]
  categories: GuildCategoryResource[]
  roles: GuildRoleResource[]
}

export type ApplicationQuestionType = "short_text" | "paragraph" | "multiple_choice" | "yes_no"

export type ApplicationQuestionOption = {
  id: string
  label: string
}

export type ApplicationQuestion = {
  id: string
  title: string
  description?: string | null
  type: ApplicationQuestionType
  required: boolean
  order: number
  options?: ApplicationQuestionOption[]
}

export type ApplicationButtonStyle = "primary" | "secondary" | "success" | "danger"

export type ApplicationPanelButton = {
  label: string
  style: ApplicationButtonStyle
  emoji?: string | null
}

export type ApplicationPanelEmbed = {
  title?: string | null
  description?: string | null
  color?: string | null
  footer?: string | null
}

export type ApplicationSubmissionStatus =
  | "pending"
  | "reviewing"
  | "accepted"
  | "rejected"
  | "waitlisted"
  | "withdrawn"

export type ApplicationReviewerNote = {
  id: string
  content: string
  createdAt: string
  author: SessionUser
}

export type ApplicationHistoryEvent = {
  id: string
  type:
    | "submitted"
    | "status_changed"
    | "note_added"
    | "note_deleted"
    | "reviewed"
    | "form_updated"
    | "panel_deployed"
  message: string
  createdAt: string
  actor?: SessionUser | null
  metadata?: Record<string, string | number | boolean | null>
}

export type ApplicationAnswer = {
  questionId: string
  questionTitle: string
  questionType: ApplicationQuestionType
  value: string | boolean | string[]
  renderedValue: string
}

export type ApplicationFormSummary = {
  id: string
  guildId: string
  name: string
  slug: string
  description?: string | null
  status: "draft" | "active" | "archived"
  questionsCount: number
  targetChannelId?: string | null
  targetChannelName?: string | null
  logChannelId?: string | null
  logChannelName?: string | null
  reviewerRoleIds: string[]
  reviewerRoleNames: string[]
  button: ApplicationPanelButton
  embed: ApplicationPanelEmbed
  messageId?: string | null
  createdAt: string
  updatedAt: string
  counts: {
    pending: number
    reviewing: number
    accepted: number
    rejected: number
    waitlisted: number
    total: number
  }
}

export type ApplicationFormDetail = ApplicationFormSummary & {
  questions: ApplicationQuestion[]
}

export type ApplicationSubmissionSummary = {
  id: string
  guildId: string
  formId: string
  formName: string
  status: ApplicationSubmissionStatus
  applicant: SessionUser
  createdAt: string
  updatedAt: string
  reviewedAt?: string | null
  latestNote?: string | null
}

export type ApplicationSubmissionDetail = ApplicationSubmissionSummary & {
  answers: ApplicationAnswer[]
  notes: ApplicationReviewerNote[]
  history: ApplicationHistoryEvent[]
}
