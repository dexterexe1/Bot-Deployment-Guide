import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import Home from "@/pages/Home"
import Login from "@/pages/Login"
import AuthCallback from "@/pages/AuthCallback"
import { RequireAuth } from "@/routes/RequireAuth"
import AppLayout from "@/pages/app/AppLayout"
import GuildSelect from "@/pages/app/GuildSelect"
import GuildOverview from "@/pages/app/GuildOverview"
import ApplicationsPage from "@/pages/app/applications"
import TicketsPage from "@/pages/app/tickets"
import ReactionRolesPage from "@/pages/app/reaction-roles"
import LoggingPage from "@/pages/app/logging"
import WelcomePage from "@/pages/app/welcome"
import AnalyticsPage from "@/pages/app/analytics"
import BotManagementPage from "@/pages/app/bot"
import TemplatesPage from "@/pages/app/templates"

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/auth/callback" element={<AuthCallback />} />

        <Route element={<RequireAuth />}>
          <Route path="/app" element={<AppLayout />}>
            <Route index element={<Navigate to="/app/select" replace />} />
            <Route path="select" element={<GuildSelect />} />
            <Route path=":guildId/overview" element={<GuildOverview />} />
            <Route path=":guildId/applications" element={<ApplicationsPage />} />
            <Route path=":guildId/tickets" element={<TicketsPage />} />
            <Route path=":guildId/reaction-roles" element={<ReactionRolesPage />} />
            <Route path=":guildId/logging" element={<LoggingPage />} />
            <Route path=":guildId/welcome" element={<WelcomePage />} />
            <Route path=":guildId/analytics" element={<AnalyticsPage />} />
            <Route path=":guildId/bot" element={<BotManagementPage />} />
            <Route path=":guildId/templates" element={<TemplatesPage />} />
          </Route>
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  )
}
