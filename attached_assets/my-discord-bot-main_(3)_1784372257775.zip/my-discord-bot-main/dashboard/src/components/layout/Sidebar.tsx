import { NavLink } from "react-router-dom"
import { LayoutDashboard, Server } from "lucide-react"
import { cn } from "@/lib/utils"
import { Separator } from "@/components/ui/separator"

type SidebarProps = {
  guildId: string | null
}

export function Sidebar({ guildId }: SidebarProps) {
  const base = guildId ? `/app/${guildId}` : "/app"

  return (
    <aside className="flex h-full w-full flex-col">
      <div className="px-4 pb-3 pt-4">
        <div className="flex items-center gap-2">
          <div className="glass grid h-9 w-9 place-items-center rounded-xl">
            <Server className="h-4 w-4 text-primary" />
          </div>
          <div className="leading-tight">
            <div className="text-sm font-semibold">United Bunnies</div>
            <div className="text-xs text-muted-foreground">Dashboard</div>
          </div>
        </div>
      </div>

      <div className="px-4">
        <Separator />
      </div>

      <nav className="flex flex-col gap-1 px-3 py-3">
        <NavLink
          to={`${base}/overview`}
          className={({ isActive }) =>
            cn(
              "glass flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground",
              isActive && "border-white/15 text-foreground",
            )
          }
        >
          <LayoutDashboard className="h-4 w-4" />
          <span>Overview</span>
        </NavLink>

        <NavLink
          to="/app/select"
          className={({ isActive }) =>
            cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground",
              isActive && "bg-white/5 text-foreground",
            )
          }
        >
          <Server className="h-4 w-4" />
          <span>Switch Server</span>
        </NavLink>
      </nav>

      <div className="mt-auto px-4 pb-4 pt-2">
        <div className="text-xs text-muted-foreground/80">Foundation build</div>
      </div>
    </aside>
  )
}

