import { Menu, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useAuthStore } from "@/stores/authStore"

type TopBarProps = {
  onOpenNav: () => void
  title: string
}

export function TopBar({ onOpenNav, title }: TopBarProps) {
  const { user, logout } = useAuthStore()
  const initials = (user?.globalName || user?.username || "U")
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("")

  const avatarUrl = user?.avatar
    ? `https://cdn.discordapp.com/avatars/${user.discordUserId}/${user.avatar}.png?size=128`
    : null

  return (
    <header className="sticky top-0 z-30 border-b border-white/5 bg-[hsl(var(--background))]/50 backdrop-blur-2xl">
      <div className="flex h-14 items-center justify-between gap-3 px-4">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={onOpenNav}
            aria-label="Open navigation"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex items-baseline gap-2">
            <div className="text-sm font-semibold">{title}</div>
          </div>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-10 gap-2 px-2">
              <Avatar className="h-8 w-8">
                {avatarUrl ? <AvatarImage src={avatarUrl} alt={user?.username ?? "User"} /> : null}
                <AvatarFallback>{initials}</AvatarFallback>
              </Avatar>
              <div className="hidden text-left md:block">
                <div className="text-sm font-semibold leading-none">{user?.globalName || user?.username}</div>
                <div className="mt-1 text-xs text-muted-foreground">Signed in</div>
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onSelect={() => logout()}>
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <div className="px-2.5 py-2 text-xs text-muted-foreground">
              Settings pages will be added in later phases.
            </div>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}

