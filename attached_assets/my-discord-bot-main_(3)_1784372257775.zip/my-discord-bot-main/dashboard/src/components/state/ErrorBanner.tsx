import { AlertTriangle } from "lucide-react"
import { cn } from "@/lib/utils"

type ErrorBannerProps = {
  title?: string
  message: string
  className?: string
}

export function ErrorBanner({ title = "Something went wrong", message, className }: ErrorBannerProps) {
  return (
    <div
      className={cn(
        "glass flex items-start gap-3 rounded-xl border border-red-500/20 bg-red-500/5 p-4 text-sm",
        className,
      )}
    >
      <AlertTriangle className="mt-0.5 h-4 w-4 text-red-300" />
      <div className="min-w-0">
        <div className="font-semibold text-red-100">{title}</div>
        <div className="mt-1 text-red-200/80">{message}</div>
      </div>
    </div>
  )
}

