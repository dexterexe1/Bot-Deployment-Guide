import type { ApiResponse } from "../../shared/types"

type RequestOptions = {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE"
  body?: unknown
  signal?: AbortSignal
}

export async function apiRequest<T>(path: string, options: RequestOptions = {}): Promise<ApiResponse<T>> {
  const resp = await fetch(path, {
    method: options.method ?? "GET",
    credentials: "include",
    headers: options.body ? { "content-type": "application/json" } : undefined,
    body: options.body ? JSON.stringify(options.body) : undefined,
    signal: options.signal,
  })

  const data = (await resp.json().catch(() => null)) as ApiResponse<T> | null
  if (data && typeof data === "object" && "ok" in data) return data as ApiResponse<T>

  if (!resp.ok) {
    return {
      ok: false,
      error: { code: "BAD_RESPONSE", message: "Unexpected server response", requestId: "unknown" },
    }
  }

  return {
    ok: false,
    error: { code: "BAD_RESPONSE", message: "Unexpected server response", requestId: "unknown" },
  }
}

export function isApiError<T>(response: ApiResponse<T>): response is Extract<ApiResponse<T>, { ok: false }> {
  return response.ok === false
}
