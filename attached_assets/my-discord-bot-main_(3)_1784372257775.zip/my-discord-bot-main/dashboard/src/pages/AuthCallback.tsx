import { useEffect } from "react"
import { Navigate } from "react-router-dom"
import { useAuthStore } from "@/stores/authStore"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export default function AuthCallback() {
  const { status, hydrate } = useAuthStore()

  useEffect(() => {
    void hydrate()
  }, [hydrate])

  if (status === "authenticated") return <Navigate to="/app/select" replace />
  if (status === "unauthenticated") return <Navigate to="/login" replace />

  return (
    <div className="grid min-h-screen place-items-center p-6">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Signing you in</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Skeleton className="h-4 w-48" />
          <Skeleton className="h-9 w-full" />
        </CardContent>
      </Card>
    </div>
  )
}

