import { useEffect } from "react"
import { Navigate } from "react-router-dom"
import { useAuthStore } from "@/stores/authStore"
import { Skeleton } from "@/components/ui/skeleton"

export default function Home() {
  const { status, hydrate } = useAuthStore()

  useEffect(() => {
    if (status === "idle") void hydrate()
  }, [hydrate, status])

  if (status === "idle" || status === "loading") {
    return (
      <div className="grid min-h-screen place-items-center p-6">
        <div className="w-full max-w-sm space-y-3">
          <Skeleton className="h-10 w-40" />
          <Skeleton className="h-5 w-64" />
          <Skeleton className="h-9 w-full" />
        </div>
      </div>
    )
  }

  if (status === "authenticated") return <Navigate to="/app/select" replace />
  return <Navigate to="/login" replace />
}
