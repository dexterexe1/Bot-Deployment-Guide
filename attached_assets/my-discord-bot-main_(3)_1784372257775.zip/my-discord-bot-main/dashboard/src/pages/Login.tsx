import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DiscordMark } from "@/ui/marks/DiscordMark"

export default function Login() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="absolute inset-0 opacity-[0.55] [mask-image:radial-gradient(ellipse_at_center,black,transparent_68%)]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(139,92,246,0.35),transparent_55%),radial-gradient(circle_at_80%_25%,rgba(59,130,246,0.3),transparent_50%),radial-gradient(circle_at_55%_85%,rgba(99,102,241,0.24),transparent_55%)]" />
      </div>

      <div className="relative mx-auto flex min-h-screen max-w-6xl items-center justify-center px-6 py-14">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="w-full max-w-md"
        >
          <Card className="shadow-[0_40px_120px_-70px_rgba(139,92,246,0.5)]">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="glass grid h-10 w-10 place-items-center rounded-2xl">
                  <div className="h-5 w-5 rounded-md bg-gradient-to-br from-violet-400 to-blue-400" />
                </div>
                <div>
                  <CardTitle>United Bunnies</CardTitle>
                  <CardDescription>Sign in to manage your server dashboard.</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                asChild
                className="h-11 w-full justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-500 to-blue-500 text-white hover:opacity-95"
              >
                <a href="/api/v1/auth/discord/login">
                  <DiscordMark className="h-4 w-4" />
                  Continue with Discord
                </a>
              </Button>
              <div className="text-xs text-muted-foreground">
                Sessions are stored securely on the server. OAuth tokens never touch browser storage.
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}

