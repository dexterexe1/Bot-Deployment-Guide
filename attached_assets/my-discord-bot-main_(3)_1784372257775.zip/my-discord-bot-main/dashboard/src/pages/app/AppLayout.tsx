import { Outlet, useLocation, useParams } from "react-router-dom"
import { useMemo, useState } from "react"
import { Sheet, SheetContent } from "@/components/ui/sheet"
import { Sidebar } from "@/components/layout/Sidebar"
import { TopBar } from "@/components/layout/TopBar"

export default function AppLayout() {
  const { guildId } = useParams()
  const location = useLocation()
  const [open, setOpen] = useState(false)

  const title = useMemo(() => {
    if (location.pathname.endsWith("/select")) return "Select Server"
    if (location.pathname.includes("/overview")) return "Overview"
    return "Dashboard"
  }, [location.pathname])

  return (
    <div className="min-h-screen md:grid md:grid-cols-[280px_1fr]">
      <div className="hidden border-r border-white/5 md:block">
        <div className="h-screen bg-[hsl(var(--background))]/40 backdrop-blur-2xl">
          <Sidebar guildId={guildId ?? null} />
        </div>
      </div>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="left" className="p-0">
          <Sidebar guildId={guildId ?? null} />
        </SheetContent>
      </Sheet>

      <div className="flex min-h-screen flex-col">
        <TopBar onOpenNav={() => setOpen(true)} title={title} />
        <main className="flex-1 px-4 py-6 md:px-8">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

