import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"
import { motion } from "framer-motion"
import type { GuildOverview } from "../../../shared/types"
import { apiRequest, isApiError } from "@/lib/api"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { ErrorBanner } from "@/components/state/ErrorBanner"
import { Separator } from "@/components/ui/separator"
import { Activity, Bot, Clock, Hash, Shield, Users } from "lucide-react"

type LoadState =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "ready"; data: GuildOverview }

function statValue(value: number | null | undefined) {
  if (value === null || value === undefined) return "Unavailable"
  return value.toLocaleString()
}

export default function GuildOverviewPage() {
  const { guildId } = useParams()
  const [state, setState] = useState<LoadState>({ status: "loading" })

  useEffect(() => {
    const controller = new AbortController()
    async function run() {
      if (!guildId) return
      setState({ status: "loading" })
      const resp = await apiRequest<GuildOverview>(`/api/v1/guilds/${guildId}/overview`, { signal: controller.signal })
      if (isApiError(resp)) {
        setState({ status: "error", message: resp.error.message })
        return
      }
      setState({ status: "ready", data: resp.data })
    }
    void run()
    return () => controller.abort()
  }, [guildId])

  if (state.status === "loading") {
    return (
      <div className="space-y-5">
        <div className="flex items-center gap-4">
          <Skeleton className="h-14 w-14 rounded-2xl" />
          <div className="space-y-2">
            <Skeleton className="h-6 w-52" />
            <Skeleton className="h-4 w-32" />
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-2xl" />
          ))}
        </div>
      </div>
    )
  }

  if (state.status === "error") {
    return <ErrorBanner message={state.message} />
  }

  const data = state.data
  const botBadge =
    data.bot.status === "online"
      ? { variant: "good" as const, label: "Bot Online" }
      : data.bot.status === "offline"
        ? { variant: "warn" as const, label: "Bot Offline" }
        : { variant: "default" as const, label: "Bot Status Unavailable" }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
      className="space-y-6"
    >
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="glass grid h-14 w-14 place-items-center rounded-2xl">
            {data.guild.iconUrl ? (
              <img alt="" className="h-12 w-12 rounded-2xl" src={data.guild.iconUrl} />
            ) : (
              <div className="h-12 w-12 rounded-2xl bg-white/5" />
            )}
          </div>
          <div className="min-w-0">
            <div className="truncate text-xl font-semibold">{data.guild.name}</div>
            <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
              <span>Guild ID: {data.guild.id}</span>
              <Separator orientation="vertical" className="h-3" />
              <Badge variant={botBadge.variant}>{botBadge.label}</Badge>
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Users className="h-4 w-4 text-primary" />
              Members
            </CardTitle>
          </CardHeader>
          <CardContent className="text-3xl font-semibold">{statValue(data.stats.memberCount)}</CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Hash className="h-4 w-4 text-secondary" />
              Channels
            </CardTitle>
          </CardHeader>
          <CardContent className="text-3xl font-semibold">{statValue(data.stats.channelCount)}</CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Shield className="h-4 w-4 text-primary" />
              Roles
            </CardTitle>
          </CardHeader>
          <CardContent className="text-3xl font-semibold">{statValue(data.stats.roleCount)}</CardContent>
        </Card>

        <Card className="md:col-span-2 xl:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Bot className="h-4 w-4 text-secondary" />
              Bot
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="flex items-center justify-between gap-3">
              <div className="text-muted-foreground">Status</div>
              <div className="font-semibold">{data.bot.status ?? "Unavailable"}</div>
            </div>
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Clock className="h-4 w-4" />
                Latency
              </div>
              <div className="font-semibold">{data.bot.latencyMs != null ? `${data.bot.latencyMs} ms` : "Unavailable"}</div>
            </div>
            <div className="flex items-center justify-between gap-3">
              <div className="text-muted-foreground">Join date</div>
              <div className="font-semibold">{data.bot.joinedAt ?? "Unavailable"}</div>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2 xl:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Activity className="h-4 w-4 text-primary" />
              Recent activity
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            {data.recentActivity.length === 0
              ? "No recent activity yet."
              : `${data.recentActivity.length.toLocaleString()} events`}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Server owner</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            {data.guild.ownerId ? data.guild.ownerId : "Unavailable"}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Dashboard version</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">{data.meta.dashboardVersion}</CardContent>
        </Card>
      </div>
    </motion.div>
  )
}
