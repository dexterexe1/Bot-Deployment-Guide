import { useEffect } from "react"
import { motion } from "framer-motion"
import { useNavigate } from "react-router-dom"
import { useGuildStore } from "@/stores/guildStore"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { ErrorBanner } from "@/components/state/ErrorBanner"
import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"

export default function GuildSelect() {
  const navigate = useNavigate()
  const { guilds, status, error, load } = useGuildStore()

  useEffect(() => {
    if (status === "idle") void load()
  }, [load, status])

  if (status === "loading" || status === "idle") {
    return (
      <div className="space-y-4">
        <div className="flex items-end justify-between gap-4">
          <div>
            <div className="text-lg font-semibold">Choose a server</div>
            <div className="mt-1 text-sm text-muted-foreground">Only servers you can manage are shown.</div>
          </div>
          <Skeleton className="h-9 w-28" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-2xl" />
          ))}
        </div>
      </div>
    )
  }

  if (status === "error") {
    return <ErrorBanner message={error ?? "Failed to load your servers."} />
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-lg font-semibold">Choose a server</div>
          <div className="mt-1 text-sm text-muted-foreground">Only servers you can manage are shown.</div>
        </div>
        <Button variant="outline" onClick={() => void load()}>
          Refresh
        </Button>
      </div>

      {guilds.length === 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>No manageable servers found</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            Discord did not return any servers where your account has Manage Server permission.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {guilds.map((g, index) => (
            <motion.button
              key={g.id}
              type="button"
              className="group text-left"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: index * 0.03 }}
              onClick={() => navigate(`/app/${g.id}/overview`)}
            >
              <Card className="h-full transition-colors group-hover:border-white/15">
                <CardContent className="flex h-full items-center gap-4 p-5">
                  <div className="glass grid h-12 w-12 place-items-center rounded-2xl">
                    {g.icon ? (
                      <img
                        alt=""
                        className="h-10 w-10 rounded-xl"
                        src={`https://cdn.discordapp.com/icons/${g.id}/${g.icon}.png?size=96`}
                      />
                    ) : (
                      <div className="h-10 w-10 rounded-xl bg-white/5" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-semibold">{g.name}</div>
                    <div className="mt-1 text-xs text-muted-foreground">Guild ID: {g.id}</div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-foreground" />
                </CardContent>
              </Card>
            </motion.button>
          ))}
        </div>
      )}
    </div>
  )
}

