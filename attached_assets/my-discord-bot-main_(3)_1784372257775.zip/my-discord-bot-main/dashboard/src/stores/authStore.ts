import { create } from "zustand"
import { apiRequest, isApiError } from "@/lib/api"
import type { SessionUser } from "../../shared/types"

type AuthState = {
  user: SessionUser | null
  status: "idle" | "loading" | "authenticated" | "unauthenticated" | "error"
  error: string | null
  hydrate: () => Promise<void>
  logout: () => Promise<void>
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  status: "idle",
  error: null,
  hydrate: async () => {
    if (get().status === "loading") return
    set({ status: "loading", error: null })
    const resp = await apiRequest<{ user: SessionUser }>("/api/v1/auth/me")
    if (isApiError(resp)) {
      if (resp.error.code === "UNAUTHENTICATED") {
        set({ user: null, status: "unauthenticated" })
        return
      }
      set({ user: null, status: "error", error: resp.error.message })
      return
    }
    set({ user: resp.data.user, status: "authenticated" })
  },
  logout: async () => {
    await apiRequest("/api/v1/auth/logout", { method: "POST" })
    set({ user: null, status: "unauthenticated" })
  },
}))
