import { create } from "zustand"
import type { GuildSummary } from "../../shared/types"
import { apiRequest, isApiError } from "@/lib/api"

type GuildState = {
  guilds: GuildSummary[]
  status: "idle" | "loading" | "ready" | "error"
  error: string | null
  load: () => Promise<void>
  reset: () => void
}

export const useGuildStore = create<GuildState>((set, get) => ({
  guilds: [],
  status: "idle",
  error: null,
  load: async () => {
    if (get().status === "loading") return
    set({ status: "loading", error: null })
    const resp = await apiRequest<{ guilds: GuildSummary[] }>("/api/v1/guilds")
    if (isApiError(resp)) {
      set({ guilds: [], status: "error", error: resp.error.message })
      return
    }
    set({ guilds: resp.data.guilds, status: "ready" })
  },
  reset: () => set({ guilds: [], status: "idle", error: null }),
}))
