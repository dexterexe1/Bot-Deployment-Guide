import { createClient } from '@blinkdotnew/sdk'

export const blink = createClient({
  projectId: import.meta.env.VITE_BLINK_PROJECT_ID || 'discord-dashboard-app-3wnxgg9d',
  publishableKey: import.meta.env.VITE_BLINK_PUBLISHABLE_KEY || 'blnk_pk_V3Z3ZUM-rjIQ7u-ddH2BBapDyEH2j77A',
  authRequired: false,
  auth: { mode: 'managed' },
})
