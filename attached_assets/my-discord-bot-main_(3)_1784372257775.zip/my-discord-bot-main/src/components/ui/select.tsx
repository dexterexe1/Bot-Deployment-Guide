import * as React from "react"
import { ChevronDown } from "lucide-react"

import { cn } from "@/lib/utils"

type SelectProps = {
  children: React.ReactNode
  value?: string
  defaultValue?: string
  onValueChange?: (value: string) => void
  disabled?: boolean
}

type SelectTriggerProps = {
  children?: React.ReactNode
  className?: string
}

type SelectContentProps = {
  children?: React.ReactNode
}

type SelectValueProps = {
  placeholder?: string
}

type SelectItemProps = {
  value: string
  children?: React.ReactNode
  disabled?: boolean
}

function getChildByType<P>(children: React.ReactNode, component: React.ComponentType<P>) {
  return React.Children.toArray(children).find(
    (child): child is React.ReactElement<P> =>
      React.isValidElement(child) && child.type === component,
  )
}

function getChildrenByType<P>(children: React.ReactNode, component: React.ComponentType<P>) {
  return React.Children.toArray(children).filter(
    (child): child is React.ReactElement<P> =>
      React.isValidElement(child) && child.type === component,
  )
}

export function Select({
  children,
  value,
  defaultValue,
  onValueChange,
  disabled = false,
}: SelectProps) {
  const trigger = getChildByType(children, SelectTrigger)
  const content = getChildByType(children, SelectContent)
  const valueNode = trigger ? getChildByType(trigger.props.children, SelectValue) : undefined
  const items = content ? getChildrenByType(content.props.children, SelectItem) : []
  const selectProps =
    value !== undefined
      ? { value }
      : defaultValue !== undefined
        ? { defaultValue }
        : {}

  return (
    <div className="relative">
      <select
        className={cn(
          "flex h-10 w-full appearance-none rounded-md border border-input bg-background px-3 py-2 pr-10 text-sm shadow-xs transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
          trigger?.props.className,
        )}
        disabled={disabled}
        onChange={(event) => onValueChange?.(event.target.value)}
        {...selectProps}
      >
        {valueNode?.props.placeholder ? (
          <option value="" disabled hidden>
            {valueNode.props.placeholder}
          </option>
        ) : null}
        {items.map((item) => (
          <option key={item.props.value} value={item.props.value} disabled={item.props.disabled}>
            {item.props.children}
          </option>
        ))}
      </select>
      <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
    </div>
  )
}

export function SelectTrigger({ children }: SelectTriggerProps) {
  return <>{children}</>
}

export function SelectContent({ children }: SelectContentProps) {
  return <>{children}</>
}

export function SelectValue(_props: SelectValueProps) {
  return null
}

export function SelectItem(_props: SelectItemProps) {
  return null
}
