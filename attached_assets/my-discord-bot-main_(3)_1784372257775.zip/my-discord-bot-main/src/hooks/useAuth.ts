import { useState, useEffect } from 'react'
import { blink } from '@/blink/client'
import type { SessionUser } from '@/types/application'

export function useAuth() {
  const [user, setUser] = useState<SessionUser | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = blink.auth.onAuthStateChanged((state) => {
      const blinkUser = state.user
      if (blinkUser) {
        setUser({
          discordUserId: blinkUser.id ?? '',
          username: blinkUser.email ?? blinkUser.id ?? 'User',
          globalName: blinkUser.displayName ?? null,
          avatar: blinkUser.avatarUrl ?? null,
        })
      } else {
        setUser(null)
      }
      if (!state.isLoading) {
        setIsLoading(false)
      }
    })
    return unsubscribe
  }, [])

  return { user, isLoading }
}
